/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2019 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_debug_console.h"
#include "fsl_flexcan.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define EXAMPLE_CAN                CAN3
#define RX_MESSAGE_BUFFER_NUM1      (9)
#define RX_MESSAGE_BUFFER_NUM2      (10)
#define TX_MESSAGE_BUFFER_NUM      (8)
#define USE_IMPROVED_TIMING_CONFIG (1)
#define DEMO_FORCE_CAN_SRC_OSC     (1)
#define USE_CANFD                  (0)
/*
 *    DWORD_IN_MB    DLC    BYTES_IN_MB             Maximum MBs
 *    2              8      kFLEXCAN_8BperMB        64
 *    4              10     kFLEXCAN_16BperMB       42
 *    8              13     kFLEXCAN_32BperMB       24
 *    16             15     kFLEXCAN_64BperMB       14
 *
 * Dword in each message buffer, Length of data in bytes, Payload size must align,
 * and the Message Buffers are limited corresponding to each payload configuration:
 */
#define DWORD_IN_MB (16)
#define BYTES_IN_MB kFLEXCAN_64BperMB
#if (defined(USE_CANFD) && USE_CANFD)
#define DLC         (15)        //��ΪĬ��ʹ����USE_CANFD�������CAN��Ҫ�޸�Ϊ8��Ĭ����15
#else
#define DLC         (8)        //��ΪĬ��ʹ����USE_CANFD�������CAN��Ҫ�޸�Ϊ8��Ĭ����15
#endif

/* The CAN clock prescaler = CAN source clock/(baud rate * quantum), and the prescaler must be an integer.
   The quantum default value is set to 10=(3+2+1)+4, because for most platforms the CAN clock frequency is
   a multiple of 10. e.g. 120M CAN source clock/(1M baud rate * 10) is an integer. If the CAN clock frequency
   is not a multiple of 10, users need to set SET_CAN_QUANTUM and define the PSEG1/PSEG2/PROPSEG (classical CAN)
   and FPSEG1/FPSEG2/FPROPSEG (CANFD) vaule. Or can set USE_IMPROVED_TIMING_CONFIG macro to use driver api to
   calculates the improved timing values. */

/* Select OSC24Mhz as master flexcan clock source */
#define FLEXCAN_CLOCK_SOURCE_SELECT (1U)
/* Clock divider for master flexcan clock source */
#define FLEXCAN_CLOCK_SOURCE_DIVIDER (1U)
/* Get frequency of flexcan clock */
#define EXAMPLE_CAN_CLK_FREQ ((CLOCK_GetRootClockFreq(kCLOCK_Root_Can3) / 100000U) * 100000U)

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
flexcan_handle_t flexcanHandle;
volatile bool txComplete = false;
volatile bool rxComplete = false;
volatile bool wakenUp    = false;
flexcan_mb_transfer_t txXfer, rxXfer1, rxXfer2;
#if (defined(USE_CANFD) && USE_CANFD)
flexcan_fd_frame_t txframe, rxframe;
#else
flexcan_frame_t txframe, rxframe;
#endif
uint32_t txIdentifier;
uint32_t rxIdentifier1, rxIdentifier2;
uint32_t MB9_Filter, MB10_Filter;

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief FlexCAN Call Back function
 */
static void flexcan_callback(CAN_Type *base, flexcan_handle_t *handle, status_t status, uint32_t result, void *userData)
{
    switch (status)
    {
        case kStatus_FLEXCAN_RxIdle:
            if (RX_MESSAGE_BUFFER_NUM1 == result)
            {
                rxComplete = true;
                rxXfer1.mbIdx = (uint8_t)RX_MESSAGE_BUFFER_NUM1;                                              //Constyu ʹ��CANFD���ж��Զ�����
                #if (defined(USE_CANFD) && USE_CANFD)
                    rxXfer1.framefd = &rxframe;
                    (void)FLEXCAN_TransferFDReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer1);
                #else
                    rxXfer1.frame = &rxframe;
                    (void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer1);      //Constyu �򿪽����жϣ���������ε���һ�μ��� ������֤        
                #endif
                PRINTF("MB %02d Received, Rx MB ID: 0x%3x, LEN=%d, Rx MB data: 0x%x-0x%x-0x%x-0x%x-0x%x-0x%x-0x%x-0x%x, Time stamp: %d\r\n", RX_MESSAGE_BUFFER_NUM1, rxframe.id >> CAN_ID_STD_SHIFT,rxframe.length, rxframe.dataByte0,rxframe.dataByte1,rxframe.dataByte2,rxframe.dataByte3,rxframe.dataByte4,rxframe.dataByte5,rxframe.dataByte6,rxframe.dataByte7, rxframe.timestamp);
            }
            else if (RX_MESSAGE_BUFFER_NUM2 == result)
            {
                rxComplete = true;
                rxXfer2.mbIdx = (uint8_t)RX_MESSAGE_BUFFER_NUM2;                                              //Constyu ʹ��CANFD���ж��Զ�����
                #if (defined(USE_CANFD) && USE_CANFD)
                    rxXfer2.framefd = &rxframe;
                    (void)FLEXCAN_TransferFDReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer2);
                #else
                    rxXfer2.frame = &rxframe;
                    (void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer2);      //Constyu �򿪽����жϣ���������ε���һ�μ��� ������֤        
                #endif
                PRINTF("MB %02d Received, Rx MB ID: 0x%3x, LEN=%d, Rx MB data: 0x%x-0x%x-0x%x-0x%x-0x%x-0x%x-0x%x-0x%x, Time stamp: %d\r\n", RX_MESSAGE_BUFFER_NUM2, rxframe.id >> CAN_ID_STD_SHIFT,rxframe.length, rxframe.dataByte0,rxframe.dataByte1,rxframe.dataByte2,rxframe.dataByte3,rxframe.dataByte4,rxframe.dataByte5,rxframe.dataByte6,rxframe.dataByte7, rxframe.timestamp);
            }
            break;

        case kStatus_FLEXCAN_TxIdle:
            if (TX_MESSAGE_BUFFER_NUM == result)
            {
                txComplete = true;
            }
            break;

        case kStatus_FLEXCAN_WakeUp:
            wakenUp = true;
            break;

        default:
            break;
    }
}

/*!
 * @brief Main function
 */
int main(void)
{
    flexcan_config_t flexcanConfig;
    flexcan_rx_mb_config_t mbConfig1, mbConfig2;
    uint8_t node_type;

    /* Initialize board hardware. */
    BOARD_ConfigMPU();
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();

    /*Clock setting for FLEXCAN*/
    clock_root_config_t rootCfg = {0};
    rootCfg.mux                 = FLEXCAN_CLOCK_SOURCE_SELECT;
    rootCfg.div                 = FLEXCAN_CLOCK_SOURCE_DIVIDER;
    CLOCK_SetRootClock(kCLOCK_Root_Can3, &rootCfg);

    PRINTF("**canfd_interrupt_transfer_cm7_using_global_mask_without_FIFO_Constyu**\r\n");
    PRINTF("    Message format: Standard (11 bit id)\r\n");
    PRINTF("    Message buffer %d and %d used for Rx.\r\n", RX_MESSAGE_BUFFER_NUM1, RX_MESSAGE_BUFFER_NUM2);
    PRINTF("    Message buffer %d used for Tx.\r\n", TX_MESSAGE_BUFFER_NUM);
    PRINTF("    Interrupt Mode: Enabled\r\n");
    PRINTF("    This demo need to test with ZLG CAN box, it send data to PC and get data from PC\r\n");
    PRINTF("*********************************************\r\n\r\n");
           
    txIdentifier = 0x321;
    rxIdentifier1 = 0x123;
    rxIdentifier2 = 0x456;

    /* Get FlexCAN module default Configuration. */
    FLEXCAN_GetDefaultConfig(&flexcanConfig);
    flexcanConfig.enableIndividMask = true;
    

#if defined(EXAMPLE_CAN_CLK_SOURCE)
    flexcanConfig.clkSrc = EXAMPLE_CAN_CLK_SOURCE;
#endif

/* If special quantum setting is needed, set the timing parameters. */
#if (defined(SET_CAN_QUANTUM) && SET_CAN_QUANTUM)
    flexcanConfig.timingConfig.phaseSeg1 = PSEG1;
    flexcanConfig.timingConfig.phaseSeg2 = PSEG2;
    flexcanConfig.timingConfig.propSeg   = PROPSEG;
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
    flexcanConfig.timingConfig.fphaseSeg1 = FPSEG1;
    flexcanConfig.timingConfig.fphaseSeg2 = FPSEG2;
    flexcanConfig.timingConfig.fpropSeg   = FPROPSEG;
#endif
#endif

#if (defined(USE_IMPROVED_TIMING_CONFIG) && USE_IMPROVED_TIMING_CONFIG)
    flexcan_timing_config_t timing_config;
    memset(&timing_config, 0, sizeof(flexcan_timing_config_t));
#if (defined(USE_CANFD) && USE_CANFD)
    if (FLEXCAN_FDCalculateImprovedTimingValues(flexcanConfig.baudRate, flexcanConfig.baudRateFD, EXAMPLE_CAN_CLK_FREQ,
                                                &timing_config))
    {
        /* Update the improved timing configuration*/
        memcpy(&(flexcanConfig.timingConfig), &timing_config, sizeof(flexcan_timing_config_t));
    }
    else
    {
        PRINTF("No found Improved Timing Configuration. Just used default configuration\r\n\r\n");
    }
#else
    if (FLEXCAN_CalculateImprovedTimingValues(flexcanConfig.baudRate, EXAMPLE_CAN_CLK_FREQ, &timing_config))
    {
        /* Update the improved timing configuration*/
        memcpy(&(flexcanConfig.timingConfig), &timing_config, sizeof(flexcan_timing_config_t));
    }
    else
    {
        PRINTF("No found Improved Timing Configuration. Just used default configuration\r\n\r\n");
    }
#endif
#endif

#if (defined(USE_CANFD) && USE_CANFD)
    FLEXCAN_FDInit(EXAMPLE_CAN, &flexcanConfig, EXAMPLE_CAN_CLK_FREQ, BYTES_IN_MB, true);
#else
    FLEXCAN_Init(EXAMPLE_CAN, &flexcanConfig, EXAMPLE_CAN_CLK_FREQ);                            //Constyu ��ʼ��FlexCAN
#endif

    /* Create FlexCAN handle structure and set call back function. */
    FLEXCAN_TransferCreateHandle(EXAMPLE_CAN, &flexcanHandle, flexcan_callback, NULL);

    /* Set Rx Individual Masking mechanism.  */
    //FLEXCAN_SetRxMbGlobalMask(EXAMPLE_CAN, FLEXCAN_RX_MB_STD_MASK(rxIdentifier, 0, 0));         //Constyu ����global mask�����ս��յ�������global mask��ID����
    MB9_Filter = 0xFF0;
    MB10_Filter= 0xF0F;
    FLEXCAN_SetRxIndividualMask(EXAMPLE_CAN, RX_MESSAGE_BUFFER_NUM1, FLEXCAN_RX_MB_STD_MASK(MB9_Filter, 0, 0));
    FLEXCAN_SetRxIndividualMask(EXAMPLE_CAN, RX_MESSAGE_BUFFER_NUM2, FLEXCAN_RX_MB_STD_MASK(MB10_Filter, 0, 0));
    
    /* Setup Rx Message Buffer. */
    mbConfig1.format = kFLEXCAN_FrameFormatStandard;                                             
    mbConfig1.type   = kFLEXCAN_FrameTypeData;
    mbConfig1.id     = FLEXCAN_ID_STD(rxIdentifier1);                                             //Constyu ���ý������ݸ�ʽ��ID

    mbConfig2.format = kFLEXCAN_FrameFormatStandard;                                             
    mbConfig2.type   = kFLEXCAN_FrameTypeData;
    mbConfig2.id     = FLEXCAN_ID_STD(rxIdentifier2);                                             //Constyu ���ý������ݸ�ʽ��ID
    
#if (defined(USE_CANFD) && USE_CANFD)
    FLEXCAN_SetFDRxMbConfig(EXAMPLE_CAN, RX_MESSAGE_BUFFER_NUM1, &mbConfig1, true);
    FLEXCAN_SetFDRxMbConfig(EXAMPLE_CAN, RX_MESSAGE_BUFFER_NUM2, &mbConfig2, true);
#else
    FLEXCAN_SetRxMbConfig(EXAMPLE_CAN, RX_MESSAGE_BUFFER_NUM1, &mbConfig1, true);                 //Constyu ����RX MB�Ľ������ݸ�ʽ������ID,֡���ͣ�MB��
    FLEXCAN_SetRxMbConfig(EXAMPLE_CAN, RX_MESSAGE_BUFFER_NUM2, &mbConfig2, true);                 //Constyu ����RX MB�Ľ������ݸ�ʽ������ID,֡���ͣ�MB��
#endif

/* Setup Tx Message Buffer. */
#if (defined(USE_CANFD) && USE_CANFD)
    FLEXCAN_SetFDTxMbConfig(EXAMPLE_CAN, TX_MESSAGE_BUFFER_NUM, true);
#else
    FLEXCAN_SetTxMbConfig(EXAMPLE_CAN, TX_MESSAGE_BUFFER_NUM, true);                            //Constyu ʹ��TX MB�Ľ������ݸ�ʽ
#endif
    
    /* Start receive data through Rx Message Buffer. */
    rxXfer1.mbIdx = (uint8_t)RX_MESSAGE_BUFFER_NUM1;                                              //Constyu ʹ��CANFD���ж��Զ�����
    rxXfer2.mbIdx = (uint8_t)RX_MESSAGE_BUFFER_NUM2;                                              //Constyu ʹ��CANFD���ж��Զ�����
#if (defined(USE_CANFD) && USE_CANFD)
    rxXfer1.framefd = &rxframe;
    rxXfer2.framefd = &rxframe;
    (void)FLEXCAN_TransferFDReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer1);
    (void)FLEXCAN_TransferFDReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer2);
#else
    rxXfer1.frame = &rxframe;
    rxXfer2.frame = &rxframe;
    (void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer1);      //Constyu �򿪽����жϣ���������ε���һ�μ��� ������֤    
    (void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer2);      //Constyu �򿪽����жϣ���������ε���һ�μ��� ������֤       
#endif

    while (true)
    {
        PRINTF("Press any key to trigger one-shot transmission\r\n\r\n");
        node_type = GETCHAR();

        txframe.id     = FLEXCAN_ID_STD(txIdentifier);
        txframe.format = (uint8_t)kFLEXCAN_FrameFormatStandard;
        txframe.type   = (uint8_t)kFLEXCAN_FrameTypeData;
        txframe.length = (uint8_t)DLC;
        txframe.dataByte0 ++;txframe.dataByte1 ++;txframe.dataByte2 ++;txframe.dataByte3 ++;
        txframe.dataByte4 ++; txframe.dataByte5 ++; txframe.dataByte6 ++; txframe.dataByte7 ++;
#if (defined(USE_CANFD) && USE_CANFD)
        txframe.brs = (uint8_t)1U;
        txframe.dataByte10 ++;                                                                 //Constyu ֧��CANFD���ܴ���8
#endif
        txXfer.mbIdx = (uint8_t)TX_MESSAGE_BUFFER_NUM;                                          //Constyu ָ��TXʹ�õ� MB number
#if (defined(USE_CANFD) && USE_CANFD)
        txXfer.framefd = &txframe;
        (void)FLEXCAN_TransferFDSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer);          
#else
        txXfer.frame = &txframe;
        (void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer);            //Constyu ʹ���жϷ��������䣬��ɺ�����callback
#endif

        while (!txComplete)
        {
        };
        txComplete = false;
        
        if(rxComplete == true)
        {
          rxComplete = false;
          //PRINTF("Data Received\r\n");
        }   
    }
}
