/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2019 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_debug_console.h"
#include "fsl_flexcan.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"
#include "fsl_flexcan_edma.h"
#include "fsl_dmamux.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define EXAMPLE_CAN                CAN3
#define RX_MESSAGE_BUFFER_NUM      (9)
#define TX_MESSAGE_BUFFER_NUM      (8)
#define USE_IMPROVED_TIMING_CONFIG (1)
#define DEMO_FORCE_CAN_SRC_OSC     (1)
#define USE_CANFD                  (0)          //CANFD��֧��FIFO
/*
 *    DWORD_IN_MB    DLC    BYTES_IN_MB             Maximum MBs
 *    2              8      kFLEXCAN_8BperMB        64
 *    4              10     kFLEXCAN_16BperMB       42
 *    8              13     kFLEXCAN_32BperMB       24
 *    16             15     kFLEXCAN_64BperMB       14
 *
 * Dword in each message buffer, Length of data in bytes, Payload size must align,
 * and the Message Buffers are limited corresponding to each payload configuration:
 */
#define DWORD_IN_MB (16)
#define BYTES_IN_MB kFLEXCAN_64BperMB
#if (defined(USE_CANFD) && USE_CANFD)
#define DLC         (15)        //��ΪĬ��ʹ����USE_CANFD�������CAN��Ҫ�޸�Ϊ8��Ĭ����15
#else
#define DLC         (8)        //��ΪĬ��ʹ����USE_CANFD�������CAN��Ҫ�޸�Ϊ8��Ĭ����15
#endif

/* The CAN clock prescaler = CAN source clock/(baud rate * quantum), and the prescaler must be an integer.
   The quantum default value is set to 10=(3+2+1)+4, because for most platforms the CAN clock frequency is
   a multiple of 10. e.g. 120M CAN source clock/(1M baud rate * 10) is an integer. If the CAN clock frequency
   is not a multiple of 10, users need to set SET_CAN_QUANTUM and define the PSEG1/PSEG2/PROPSEG (classical CAN)
   and FPSEG1/FPSEG2/FPROPSEG (CANFD) vaule. Or can set USE_IMPROVED_TIMING_CONFIG macro to use driver api to
   calculates the improved timing values. */

/* Select OSC24Mhz as master flexcan clock source */
#define FLEXCAN_CLOCK_SOURCE_SELECT (1U)
/* Clock divider for master flexcan clock source */
#define FLEXCAN_CLOCK_SOURCE_DIVIDER (1U)
/* Get frequency of flexcan clock */
#define EXAMPLE_CAN_CLK_FREQ ((CLOCK_GetRootClockFreq(kCLOCK_Root_Can3) / 100000U) * 100000U)

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
flexcan_handle_t flexcanHandle;
flexcan_edma_handle_t flexcanEdmaHandle;
volatile bool dmarxComplete = false;

volatile bool txComplete = false;
volatile bool rxComplete = false;
volatile bool wakenUp    = false;
flexcan_mb_transfer_t txXfer;
flexcan_fifo_transfer_t FifoXfer;
//#if (defined(USE_CANFD) && USE_CANFD)
//flexcan_fd_frame_t txframe, rxframe;
//#else
flexcan_frame_t txframe, rxframe;
//AT_NONCACHEABLE_SECTION(flexcan_frame_t rxFrame);
//#endif
uint32_t txIdentifier;
uint32_t rxIdentifier;
uint32_t RX_FIFO_Filter_Table[] ={FLEXCAN_RX_FIFO_STD_FILTER_TYPE_A(0x123, 0, 0),
                                  FLEXCAN_RX_FIFO_STD_FILTER_TYPE_A(0x456, 0, 0),
                                  FLEXCAN_RX_FIFO_STD_FILTER_TYPE_A(0x003, 0, 0),
                                  FLEXCAN_RX_FIFO_STD_FILTER_TYPE_A(0x223, 0, 0),
                                  FLEXCAN_RX_FIFO_STD_FILTER_TYPE_A(0x256, 0, 0),
                                  FLEXCAN_RX_FIFO_STD_FILTER_TYPE_A(0x278, 0, 0),
                                  FLEXCAN_RX_FIFO_STD_FILTER_TYPE_A(0x333, 0, 0),
                                  FLEXCAN_RX_FIFO_STD_FILTER_TYPE_A(0x356, 0, 0),
                                  };

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief FlexCAN Call Back function
 */
static void flexcan_callback(CAN_Type *base, flexcan_handle_t *handle, status_t status, uint32_t result, void *userData)
{
    //PRINTF("status= %d, result=%d \r\n", (int32_t)status, result);
    switch (status)
    {
        case kStatus_FLEXCAN_RxIdle:
                rxComplete = true;
                #if (defined(USE_CANFD) && USE_CANFD)
                    FifoXfer.framefd = &rxframe;
                    (void)FLEXCAN_TransferFDReceiveFifoNonBlocking(EXAMPLE_CAN, &flexcanHandle, &FifoXfer);
                #else
                    FifoXfer.frame = &rxframe;
                    (void)FLEXCAN_TransferReceiveFifoNonBlocking(EXAMPLE_CAN, &flexcanHandle, &FifoXfer);      //Constyu �򿪽����жϣ���������ε���һ�μ��� ������֤        
                #endif
                PRINTF("Rx MB ID: 0x%03x, LEN=%d, Rx MB data: 0x%x-0x%x-0x%x-0x%x-0x%x-0x%x-0x%x-0x%x, Time stamp: %d\r\n",  rxframe.id >> CAN_ID_STD_SHIFT,rxframe.length, rxframe.dataByte0,rxframe.dataByte1,rxframe.dataByte2,rxframe.dataByte3,rxframe.dataByte4,rxframe.dataByte5,rxframe.dataByte6,rxframe.dataByte7, rxframe.timestamp);
            
            break;
        case kStatus_FLEXCAN_RxFifoIdle:
            rxComplete = true;
            #if (defined(USE_CANFD) && USE_CANFD)
                FifoXfer.framefd = &rxframe;
                (void)FLEXCAN_TransferFDReceiveFifoNonBlocking(EXAMPLE_CAN, &flexcanHandle, &FifoXfer);
            #else
                FifoXfer.frame = &rxframe;
                (void)FLEXCAN_TransferReceiveFifoNonBlocking(EXAMPLE_CAN, &flexcanHandle, &FifoXfer);      //Constyu �򿪽����жϣ���������ε���һ�μ��� ������֤        
            #endif
            PRINTF("Rx MB ID:0x%03x, LEN=%03d, Rx MB data: 0x%x-0x%x-0x%x-0x%x-0x%x-0x%x-0x%x-0x%x, Time stamp: %d\r\n",  rxframe.id >> CAN_ID_STD_SHIFT,rxframe.length, rxframe.dataByte0,rxframe.dataByte1,rxframe.dataByte2,rxframe.dataByte3,rxframe.dataByte4,rxframe.dataByte5,rxframe.dataByte6,rxframe.dataByte7, rxframe.timestamp);
    
            break;

        case kStatus_FLEXCAN_TxIdle:
            if (TX_MESSAGE_BUFFER_NUM == result)
            {
                txComplete = true;
            }
            break;

        case kStatus_FLEXCAN_WakeUp:
            wakenUp = true;
            break;

        default:
            break;
    }
}

static void flexcan_dma_callback(CAN_Type *base, flexcan_edma_handle_t *handle, status_t status, void *userData)
{
    /* Process FlexCAN Rx event. */
    if (kStatus_FLEXCAN_RxFifoIdle == status)
    {
        dmarxComplete = true;
        FifoXfer.frame = &rxframe;
        (void)FLEXCAN_TransferReceiveFifoEDMA(EXAMPLE_CAN, &flexcanEdmaHandle, &FifoXfer);
        PRINTF("Rx MB ID: 0x%03x, LEN=%d,word0 = 0x%08x, word1 = 0x%08x, ID Filter Hit%d.\r\n", rxframe.id>>CAN_ID_STD_SHIFT, rxframe.length,rxframe.dataWord0,rxframe.dataWord1, rxframe.idhit);
    }
}

/*!
 * @brief Main function
 */
int main(void)
{
    edma_config_t edmaConfig;
    edma_handle_t flexcanRxFifoEdmaHandle;
    
    flexcan_config_t flexcanConfig;
    //flexcan_rx_mb_config_t mbConfig;
    flexcan_rx_fifo_config_t CAN3_rx_fifo_config = {
      .idFilterNum = 8,
      .idFilterType = kFLEXCAN_RxFifoFilterTypeA,
      .priority = kFLEXCAN_RxFifoPrioLow
    };
    
    //uint8_t node_type;
    txIdentifier = 0x321;
    rxIdentifier = 0x123;
    
    /* Initialize board hardware. */
    BOARD_ConfigMPU();
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();

    /*Clock setting for FLEXCAN*/
    clock_root_config_t rootCfg = {0};
    rootCfg.mux                 = FLEXCAN_CLOCK_SOURCE_SELECT;
    rootCfg.div                 = FLEXCAN_CLOCK_SOURCE_DIVIDER;
    CLOCK_SetRootClock(kCLOCK_Root_Can3, &rootCfg);

    PRINTF("**canfd_interrupt_transfer_cm7_using_global_mask_with_FIFO_with_DMA_Constyu**\r\n");
    PRINTF("    Message format: Standard (11 bit id)\r\n");
    PRINTF("    Message buffer %d used for Rx.\r\n", RX_MESSAGE_BUFFER_NUM);
    PRINTF("    Message buffer %d used for Tx.\r\n", TX_MESSAGE_BUFFER_NUM);
    PRINTF("    Author: constyu@nxp.com \r\n");
    PRINTF("    This demo need to test with Peak CAN, it send data to PCAN and get data from PCAN \r\n");
    PRINTF("*********************************************\r\n\r\n");
    
    /* Get FlexCAN module default Configuration. */
    FLEXCAN_GetDefaultConfig(&flexcanConfig);
    flexcanConfig.enableIndividMask = false;

#if defined(EXAMPLE_CAN_CLK_SOURCE)
    flexcanConfig.clkSrc = EXAMPLE_CAN_CLK_SOURCE;
#endif

/* If special quantum setting is needed, set the timing parameters. */
#if (defined(SET_CAN_QUANTUM) && SET_CAN_QUANTUM)
    flexcanConfig.timingConfig.phaseSeg1 = PSEG1;
    flexcanConfig.timingConfig.phaseSeg2 = PSEG2;
    flexcanConfig.timingConfig.propSeg   = PROPSEG;
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
    flexcanConfig.timingConfig.fphaseSeg1 = FPSEG1;
    flexcanConfig.timingConfig.fphaseSeg2 = FPSEG2;
    flexcanConfig.timingConfig.fpropSeg   = FPROPSEG;
#endif
#endif

#if (defined(USE_IMPROVED_TIMING_CONFIG) && USE_IMPROVED_TIMING_CONFIG)
    flexcan_timing_config_t timing_config;
    memset(&timing_config, 0, sizeof(flexcan_timing_config_t));
#if (defined(USE_CANFD) && USE_CANFD)
    if (FLEXCAN_FDCalculateImprovedTimingValues(flexcanConfig.baudRate, flexcanConfig.baudRateFD, EXAMPLE_CAN_CLK_FREQ,
                                                &timing_config))
    {
        /* Update the improved timing configuration*/
        memcpy(&(flexcanConfig.timingConfig), &timing_config, sizeof(flexcan_timing_config_t));
    }
    else
    {
        PRINTF("No found Improved Timing Configuration. Just used default configuration\r\n\r\n");
    }
#else
    if (FLEXCAN_CalculateImprovedTimingValues(flexcanConfig.baudRate, EXAMPLE_CAN_CLK_FREQ, &timing_config))
    {
        /* Update the improved timing configuration*/
        memcpy(&(flexcanConfig.timingConfig), &timing_config, sizeof(flexcan_timing_config_t));
    }
    else
    {
        PRINTF("No found Improved Timing Configuration. Just used default configuration\r\n\r\n");
    }
#endif
#endif

#if (defined(USE_CANFD) && USE_CANFD)
    FLEXCAN_FDInit(EXAMPLE_CAN, &flexcanConfig, EXAMPLE_CAN_CLK_FREQ, BYTES_IN_MB, true);
#else
    FLEXCAN_Init(EXAMPLE_CAN, &flexcanConfig, EXAMPLE_CAN_CLK_FREQ);                            //Constyu ��ʼ��FlexCAN
#endif

    /* Configure DMA. */
    DMAMUX_Init(DMAMUX0);
    DMAMUX_SetSource(DMAMUX0, 0, kDmaRequestMuxCAN3);
    DMAMUX_EnableChannel(DMAMUX0, 0);
    
    /*
   * edmaConfig.enableRoundRobinArbitration = false;
   * edmaConfig.enableHaltOnError = true;
   * edmaConfig.enableContinuousLinkMode = false;
   * edmaConfig.enableDebugMode = false;
   */
    EDMA_GetDefaultConfig(&edmaConfig);
    EDMA_Init(DMA0, &edmaConfig);
    
    /* Create EDMA handle. */
    EDMA_CreateHandle(&flexcanRxFifoEdmaHandle, DMA0, 0);
    
    /* Setup Tx Message Buffer. */
    FLEXCAN_SetTxMbConfig(EXAMPLE_CAN, TX_MESSAGE_BUFFER_NUM, true);                            //Constyu ʹ��TX MB�Ľ������ݸ�ʽ

       /* Set Rx Masking mechanism.  */
    CAN3_rx_fifo_config.idFilterTable = RX_FIFO_Filter_Table;
    CAN3_rx_fifo_config.idFilterNum  = sizeof(RX_FIFO_Filter_Table) / sizeof(RX_FIFO_Filter_Table[0]);;
    FLEXCAN_SetRxFifoConfig(CAN3, &CAN3_rx_fifo_config,true);

    if(flexcanConfig.enableIndividMask){
        FLEXCAN_SetRxIndividualMask(EXAMPLE_CAN, 0, FLEXCAN_RX_FIFO_STD_MASK_TYPE_A(0XFF0, 0, 0));
        FLEXCAN_SetRxIndividualMask(EXAMPLE_CAN, 1, FLEXCAN_RX_FIFO_STD_MASK_TYPE_A(0XF0F, 0, 0));
        FLEXCAN_SetRxIndividualMask(EXAMPLE_CAN, 2, FLEXCAN_RX_FIFO_STD_MASK_TYPE_A(0XFF0, 0, 0));
    }
    else
        FLEXCAN_SetRxFifoGlobalMask(EXAMPLE_CAN, FLEXCAN_RX_FIFO_STD_MASK_TYPE_A(0XFF0, 0,0));
    
    /* Create FlexCAN handle structure and set call back function. */
    FLEXCAN_TransferCreateHandle(EXAMPLE_CAN, &flexcanHandle, flexcan_callback, NULL);
    
    /* Create FlexCAN EDMA handle structure and set call back function. */
    FLEXCAN_TransferCreateHandleEDMA(EXAMPLE_CAN, &flexcanEdmaHandle, flexcan_dma_callback, NULL, &flexcanRxFifoEdmaHandle);  
 
    FifoXfer.frame = &rxframe;  
    FLEXCAN_TransferReceiveFifoEDMA(EXAMPLE_CAN, &flexcanEdmaHandle, &FifoXfer); 
    
    while (true)
    {
        PRINTF("Press any key to trigger one-shot transmission\r\n\r\n");
        GETCHAR();

        txframe.id     = FLEXCAN_ID_STD(txIdentifier);
        txframe.format = (uint8_t)kFLEXCAN_FrameFormatStandard;
        txframe.type   = (uint8_t)kFLEXCAN_FrameTypeData;
        txframe.length = (uint8_t)DLC;
        txframe.dataByte0 ++;
        txframe.dataByte7 ++;
#if (defined(USE_CANFD) && USE_CANFD)
        txframe.brs = (uint8_t)1U;
        txframe.dataByte10 ++;                                                                 //Constyu ֧��CANFD���ܴ���8
#endif
        txXfer.mbIdx = (uint8_t)TX_MESSAGE_BUFFER_NUM;                                          //Constyu ָ��TXʹ�õ� MB number
#if (defined(USE_CANFD) && USE_CANFD)
        txXfer.framefd = &txframe;
        (void)FLEXCAN_TransferFDSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer);          
#else
        txXfer.frame = &txframe;
        (void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer);            //Constyu ʹ���жϷ��������䣬��ɺ�����callback
#endif

//#if (defined(USE_CANFD) && USE_CANFD)
//        FifoXfer.framefd = &rxframe;
//        (void)FLEXCAN_TransferFDReceiveFifoNonBlocking(EXAMPLE_CAN, &flexcanHandle, &FifoXfer);
//#else
//        FifoXfer.frame = &rxframe;
//        (void)FLEXCAN_TransferReceiveFifoNonBlocking(EXAMPLE_CAN, &flexcanHandle, &FifoXfer);      //Constyu �򿪽����жϣ���������ε���һ�μ��� ������֤        
//#endif
        
        while (!txComplete)
        {
        };
        txComplete = false;
        
        if(rxComplete == true)
        {
          rxComplete = false;
          //PRINTF("Data Received\r\n");
        }   
    }
}
